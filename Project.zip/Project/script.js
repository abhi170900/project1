const nav  = document.querySelector(".navbar");
        const hamburger = document.querySelector("#hamburger");

        hamburger.addEventListener('click',()=>{

            nav.classList.toggle("open");

            console.log("clicked!")

        })


document.addEventListener("DOMContentLoaded", function () {
  let currentSlide = 0;

  function showSlide(index) {
      const slider = document.querySelector(".slider");
      const slides = document.querySelectorAll(".slide");

      if (index < 0) {
          currentSlide = slides.length - 1;
      } else if (index >= slides.length) {
          currentSlide = 0;
      } else {
          currentSlide = index;
      }

      const translateValue = -currentSlide * 100 + "%";
      slider.style.transform = "translateX(" + translateValue + ")";
  }

  // Auto slide change every 5 seconds (adjust as needed)
  setInterval(function () {
      showSlide(currentSlide + 1);
  }, 5000);

  // Initial slide
  showSlide(currentSlide);
});
